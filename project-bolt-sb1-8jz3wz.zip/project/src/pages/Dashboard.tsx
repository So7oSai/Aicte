import React from 'react';
import Stats from '../components/dashboard/Stats';
import RecentActivity from '../components/dashboard/RecentActivity';
import AnalyticsChart from '../components/dashboard/AnalyticsChart';

export default function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800">Dashboard Overview</h2>
        <p className="text-gray-600">Monitor and manage approval processes</p>
      </div>

      <div className="space-y-8">
        <Stats />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <RecentActivity />
          <AnalyticsChart />
        </div>
      </div>
    </div>
  );
}