import React from 'react';
import { Building2, Search, Filter, MapPin } from 'lucide-react';
import { Institution } from '../../types';

const institutions: Institution[] = [
  {
    id: 'INS001',
    name: 'Technical Institute of Engineering',
    type: 'Engineering College',
    location: 'Mumbai, Maharashtra',
    status: 'approved',
    lastUpdated: '2024-03-15'
  },
  {
    id: 'INS002',
    name: 'Advanced Technology College',
    type: 'Polytechnic',
    location: 'Delhi, NCR',
    status: 'pending',
    lastUpdated: '2024-03-14'
  },
  {
    id: 'INS003',
    name: 'Institute of Computer Science',
    type: 'Technical Institute',
    location: 'Bangalore, Karnataka',
    status: 'approved',
    lastUpdated: '2024-03-13'
  }
];

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  under_review: 'bg-blue-100 text-blue-800'
};

export default function InstitutionList() {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Registered Institutions</h2>
          <button className="btn-primary flex items-center space-x-2">
            <Building2 className="h-4 w-4" />
            <span>Add Institution</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {institutions.map((institution) => (
            <div key={institution.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <Building2 className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{institution.name}</h3>
                    <p className="text-sm text-gray-500">{institution.type}</p>
                  </div>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[institution.status]}`}>
                  {institution.status.toUpperCase()}
                </span>
              </div>

              <div className="mt-4 flex items-center text-sm text-gray-500">
                <MapPin className="h-4 w-4 mr-1" />
                {institution.location}
              </div>

              <div className="mt-4 flex justify-between items-center">
                <span className="text-xs text-gray-500">
                  Last updated: {new Date(institution.lastUpdated).toLocaleDateString()}
                </span>
                <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}