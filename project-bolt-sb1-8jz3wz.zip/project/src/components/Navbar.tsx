import React, { useState } from 'react';
import { Menu, Search, Bell, User, X } from 'lucide-react';

interface NavbarProps {
  onMenuToggle: () => void;
}

export default function Navbar({ onMenuToggle }: NavbarProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, text: 'New application submitted', unread: true },
    { id: 2, text: 'Document verification completed', unread: true },
    { id: 3, text: 'Application status updated', unread: false },
  ]);
  const [showNotifications, setShowNotifications] = useState(false);

  const handleNotificationClick = (id: number) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, unread: false } : notif
    ));
  };

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <nav className="bg-white shadow-lg relative z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <button 
              onClick={onMenuToggle}
              className="p-2 rounded-md text-gray-600 lg:hidden hover:bg-gray-100"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-3">
              <img 
                src="https://upload.wikimedia.org/wikipedia/en/e/eb/All_India_Council_for_Technical_Education_logo.png" 
                alt="AICTE Logo" 
                className="h-10 w-auto"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-800">AICTE Portal</h1>
                <p className="text-sm text-gray-500">AI-Powered Approval Process</p>
              </div>
            </div>
          </div>

          <div className="hidden lg:flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search..."
                className="w-64 pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-full"
              >
                <Bell className="h-6 w-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-2 border border-gray-200">
                  <div className="px-4 py-2 border-b border-gray-200">
                    <h3 className="font-semibold text-gray-800">Notifications</h3>
                  </div>
                  {notifications.map((notif) => (
                    <button
                      key={notif.id}
                      onClick={() => handleNotificationClick(notif.id)}
                      className={`w-full px-4 py-3 text-left hover:bg-gray-50 ${
                        notif.unread ? 'bg-blue-50' : ''
                      }`}
                    >
                      <p className={`text-sm ${notif.unread ? 'font-semibold' : ''}`}>
                        {notif.text}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <User className="h-8 w-8 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Admin Portal</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}