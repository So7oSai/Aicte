import React from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Settings, 
  Users, 
  Bell, 
  HelpCircle,
  LogOut,
  X
} from 'lucide-react';

interface SidebarProps {
  onPageChange: (page: string) => void;
  currentPage: string;
  isMobileMenuOpen: boolean;
  onCloseMobileMenu: () => void;
}

const menuItems = [
  { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { id: 'applications', icon: FileText, label: 'Applications' },
  { id: 'institutions', icon: Users, label: 'Institutions' },
  { id: 'notifications', icon: Bell, label: 'Notifications' },
  { id: 'settings', icon: Settings, label: 'Settings' },
  { id: 'help', icon: HelpCircle, label: 'Help & Support' },
];

export default function Sidebar({ 
  onPageChange, 
  currentPage, 
  isMobileMenuOpen,
  onCloseMobileMenu 
}: SidebarProps) {
  const handlePageChange = (pageId: string) => {
    onPageChange(pageId);
    onCloseMobileMenu();
  };

  const sidebarClasses = `
    ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
    lg:translate-x-0 
    fixed lg:relative 
    inset-y-0 left-0 
    w-64 
    bg-white 
    border-r border-gray-200 
    transform 
    transition-transform 
    duration-200 
    ease-in-out 
    z-30
    flex flex-col
  `;

  return (
    <>
      {/* Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 lg:hidden z-20"
          onClick={onCloseMobileMenu}
        />
      )}

      {/* Sidebar */}
      <div className={sidebarClasses}>
        <div className="flex justify-between items-center p-4 lg:hidden">
          <h2 className="font-semibold text-gray-800">Menu</h2>
          <button 
            onClick={onCloseMobileMenu}
            className="p-2 rounded-md text-gray-600 hover:bg-gray-100"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="flex-1 py-6 overflow-y-auto">
          <nav className="px-4 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => handlePageChange(item.id)}
                  className={`flex items-center space-x-3 w-full px-4 py-2.5 text-left rounded-lg 
                    ${currentPage === item.id
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-100'
                    }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-gray-200">
          <button 
            onClick={() => {
              // Handle logout
              console.log('Logging out...');
            }}
            className="flex items-center space-x-3 w-full px-4 py-2.5 text-left text-red-600 rounded-lg hover:bg-red-50"
          >
            <LogOut className="h-5 w-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </div>
    </>
  );
}