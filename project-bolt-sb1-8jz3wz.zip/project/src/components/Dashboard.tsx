import React from 'react';
import { 
  BarChart3, 
  FileCheck, 
  Clock, 
  AlertCircle, 
  CheckCircle2,
  Building2
} from 'lucide-react';

const stats = [
  { 
    title: 'Pending Applications', 
    value: '156', 
    change: '+12%', 
    icon: Clock,
    color: 'text-yellow-600',
    bg: 'bg-yellow-100' 
  },
  { 
    title: 'Approved', 
    value: '892', 
    change: '+23%', 
    icon: CheckCircle2,
    color: 'text-green-600',
    bg: 'bg-green-100'
  },
  { 
    title: 'Under Review', 
    value: '64', 
    change: '-8%', 
    icon: FileCheck,
    color: 'text-blue-600',
    bg: 'bg-blue-100'
  },
  { 
    title: 'Rejected', 
    value: '23', 
    change: '-2%', 
    icon: AlertCircle,
    color: 'text-red-600',
    bg: 'bg-red-100'
  }
];

export default function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800">Dashboard Overview</h2>
        <p className="text-gray-600">Monitor and manage approval processes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.bg} p-3 rounded-lg`}>
                  <Icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <span className={`text-sm font-medium ${
                  stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-gray-800">{stat.value}</h3>
              <p className="text-gray-600">{stat.title}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-800">Recent Applications</h3>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map((_, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <Building2 className="h-10 w-10 text-gray-600" />
                  <div>
                    <h4 className="font-medium text-gray-800">Technical Institute {index + 1}</h4>
                    <p className="text-sm text-gray-600">Application ID: #APL{2024000 + index}</p>
                  </div>
                </div>
                <span className="px-3 py-1 text-sm font-medium rounded-full bg-yellow-100 text-yellow-800">
                  In Progress
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-800">Application Analytics</h3>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              Download Report
            </button>
          </div>
          <div className="h-64 flex items-center justify-center">
            <BarChart3 className="h-40 w-40 text-gray-400" />
          </div>
        </div>
      </div>
    </div>
  );
}