import React from 'react';
import { Clock } from 'lucide-react';

const activities = [
  {
    id: 1,
    type: 'application_submitted',
    institution: 'Technical Institute of Engineering',
    time: '2 hours ago',
    description: 'Submitted new application for B.Tech program approval'
  },
  {
    id: 2,
    type: 'application_approved',
    institution: 'Advanced Technology College',
    time: '4 hours ago',
    description: 'Application APL20240002 has been approved'
  },
  {
    id: 3,
    type: 'document_verification',
    institution: 'Institute of Computer Science',
    time: '6 hours ago',
    description: 'Documents verified for extension application'
  },
  {
    id: 4,
    type: 'review_assigned',
    institution: 'Digital Engineering College',
    time: '8 hours ago',
    description: 'Application assigned to Dr. Sharma for review'
  }
];

export default function RecentActivity() {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-800">Recent Activity</h3>
        <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
          View All
        </button>
      </div>

      <div className="space-y-6">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-4">
            <div className="bg-blue-100 p-2 rounded-full">
              <Clock className="h-5 w-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">{activity.institution}</p>
              <p className="text-sm text-gray-500">{activity.description}</p>
              <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}