import React from 'react';
import { 
  FileCheck, 
  Clock, 
  AlertCircle, 
  CheckCircle2,
  Building2,
  Users
} from 'lucide-react';

const stats = [
  { 
    title: 'Total Institutions', 
    value: '1,234', 
    change: '+8%', 
    icon: Building2,
    color: 'text-purple-600',
    bg: 'bg-purple-100' 
  },
  { 
    title: 'Active Applications', 
    value: '156', 
    change: '+12%', 
    icon: Clock,
    color: 'text-yellow-600',
    bg: 'bg-yellow-100' 
  },
  { 
    title: 'Approved', 
    value: '892', 
    change: '+23%', 
    icon: CheckCircle2,
    color: 'text-green-600',
    bg: 'bg-green-100'
  },
  { 
    title: 'Under Review', 
    value: '64', 
    change: '-8%', 
    icon: FileCheck,
    color: 'text-blue-600',
    bg: 'bg-blue-100'
  },
  { 
    title: 'Rejected', 
    value: '23', 
    change: '-2%', 
    icon: AlertCircle,
    color: 'text-red-600',
    bg: 'bg-red-100'
  },
  { 
    title: 'Active Users', 
    value: '2,456', 
    change: '+15%', 
    icon: Users,
    color: 'text-indigo-600',
    bg: 'bg-indigo-100'
  }
];

export default function Stats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div key={index} className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`${stat.bg} p-3 rounded-lg`}>
                <Icon className={`h-6 w-6 ${stat.color}`} />
              </div>
              <span className={`text-sm font-medium ${
                stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.change}
              </span>
            </div>
            <h3 className="text-2xl font-bold text-gray-800">{stat.value}</h3>
            <p className="text-gray-600">{stat.title}</p>
          </div>
        );
      })}
    </div>
  );
}