import React from 'react';
import { BarChart3, Download } from 'lucide-react';

export default function AnalyticsChart() {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">Application Analytics</h3>
          <p className="text-sm text-gray-500">Monthly application statistics</p>
        </div>
        <button className="btn-secondary flex items-center space-x-2">
          <Download className="h-4 w-4" />
          <span>Export</span>
        </button>
      </div>
      
      <div className="h-64 flex items-center justify-center border-t border-gray-100 pt-6">
        <div className="text-center">
          <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <p className="text-sm text-gray-500">Analytics visualization would go here</p>
          <p className="text-xs text-gray-400">Monthly application trends and statistics</p>
        </div>
      </div>
    </div>
  );
}