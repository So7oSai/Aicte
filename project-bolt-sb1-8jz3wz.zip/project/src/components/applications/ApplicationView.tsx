import React, { useState } from 'react';
import { Application } from '../../types';
import { 
  X, 
  FileText, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  MessageSquare,
  Download
} from 'lucide-react';

interface ApplicationViewProps {
  application: Application;
  onClose: () => void;
}

export default function ApplicationView({ application, onClose }: ApplicationViewProps) {
  const [activeTab, setActiveTab] = useState('details');
  const [comment, setComment] = useState('');

  const handleAddComment = () => {
    if (comment.trim()) {
      console.log('Adding comment:', comment);
      setComment('');
    }
  };

  const handleStatusChange = (newStatus: Application['status']) => {
    console.log('Changing status to:', newStatus);
    // Implementation for status change
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">
              Application Details - {application.id}
            </h2>
            <p className="text-sm text-gray-500">
              Submitted on {new Date(application.submissionDate).toLocaleDateString()}
            </p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('details')}
            className={`px-6 py-3 text-sm font-medium border-b-2 ${
              activeTab === 'details'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Details
          </button>
          <button
            onClick={() => setActiveTab('documents')}
            className={`px-6 py-3 text-sm font-medium border-b-2 ${
              activeTab === 'documents'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Documents
          </button>
          <button
            onClick={() => setActiveTab('comments')}
            className={`px-6 py-3 text-sm font-medium border-b-2 ${
              activeTab === 'comments'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Comments
          </button>
        </div>

        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {activeTab === 'details' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Institution Name</h3>
                  <p className="mt-1 text-sm text-gray-900">{application.institutionName}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Application Type</h3>
                  <p className="mt-1 text-sm text-gray-900 capitalize">{application.type}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Status</h3>
                  <p className="mt-1">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      application.status === 'approved' ? 'bg-green-100 text-green-800' :
                      application.status === 'rejected' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {application.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </p>
                </div>
              </div>

              {/* Status Actions */}
              <div className="mt-6 border-t border-gray-200 pt-6">
                <h3 className="text-sm font-medium text-gray-500 mb-4">Update Status</h3>
                <div className="flex space-x-4">
                  <button
                    onClick={() => handleStatusChange('approved')}
                    className="flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200"
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Approve
                  </button>
                  <button
                    onClick={() => handleStatusChange('rejected')}
                    className="flex items-center px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
                  >
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Reject
                  </button>
                  <button
                    onClick={() => handleStatusChange('under_review')}
                    className="flex items-center px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200"
                  >
                    <Clock className="h-4 w-4 mr-2" />
                    Mark Under Review
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-4">
              {application.documents.map(doc => (
                <div key={doc.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{doc.name}</p>
                      <p className="text-xs text-gray-500">PDF Document</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      doc.status === 'verified' ? 'bg-green-100 text-green-800' :
                      doc.status === 'rejected' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {doc.status.toUpperCase()}
                    </span>
                    <button className="text-blue-600 hover:text-blue-800">
                      <Download className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'comments' && (
            <div className="space-y-6">
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  placeholder="Add a comment..."
                  className="input-field flex-1"
                />
                <button 
                  onClick={handleAddComment}
                  className="btn-primary flex items-center space-x-2"
                >
                  <MessageSquare className="h-4 w-4" />
                  <span>Comment</span>
                </button>
              </div>

              <div className="space-y-4">
                {/* Sample comments - replace with actual comments data */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="font-medium text-gray-900">John Doe</div>
                    <div className="text-sm text-gray-500">2 hours ago</div>
                  </div>
                  <p className="text-gray-700">
                    Documents have been verified. Infrastructure meets requirements.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}