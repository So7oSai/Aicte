import React, { useState } from 'react';
import { FileText, Upload, X, Check } from 'lucide-react';

interface DocumentUpload {
  id: string;
  name: string;
  status: 'uploading' | 'completed' | 'error';
  progress: number;
}

export default function ApplicationForm({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(1);
  const [documents, setDocuments] = useState<DocumentUpload[]>([]);
  const [formData, setFormData] = useState({
    institutionName: '',
    applicationType: 'new',
    programType: '',
    intake: '',
    academicYear: '2024-25',
  });

  const requiredDocs = [
    'Institution Registration Certificate',
    'Land Documents',
    'Building Plan Approval',
    'Faculty Details',
    'Infrastructure Details',
    'Financial Statements'
  ];

  const handleDocumentUpload = (name: string) => {
    const newDoc: DocumentUpload = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      status: 'uploading',
      progress: 0
    };

    setDocuments([...documents, newDoc]);

    // Simulate upload progress
    const interval = setInterval(() => {
      setDocuments(prev => prev.map(doc => {
        if (doc.id === newDoc.id) {
          const progress = doc.progress + 20;
          if (progress >= 100) {
            clearInterval(interval);
            return { ...doc, progress: 100, status: 'completed' };
          }
          return { ...doc, progress };
        }
        return doc;
      }));
    }, 500);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-800">New Application</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Institution Name
                </label>
                <input
                  type="text"
                  className="input-field"
                  value={formData.institutionName}
                  onChange={e => setFormData({...formData, institutionName: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Application Type
                </label>
                <select 
                  className="input-field"
                  value={formData.applicationType}
                  onChange={e => setFormData({...formData, applicationType: e.target.value})}
                >
                  <option value="new">New Institution</option>
                  <option value="renewal">Renewal</option>
                  <option value="extension">Extension of Approval</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Program Type
                </label>
                <select 
                  className="input-field"
                  value={formData.programType}
                  onChange={e => setFormData({...formData, programType: e.target.value})}
                >
                  <option value="">Select Program Type</option>
                  <option value="engineering">Engineering</option>
                  <option value="management">Management</option>
                  <option value="pharmacy">Pharmacy</option>
                  <option value="architecture">Architecture</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Proposed Intake
                </label>
                <input
                  type="number"
                  className="input-field"
                  value={formData.intake}
                  onChange={e => setFormData({...formData, intake: e.target.value})}
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Required Documents</h3>
              <p className="text-sm text-gray-500">Upload all mandatory documents in PDF format</p>

              <div className="space-y-4">
                {requiredDocs.map(doc => {
                  const uploadedDoc = documents.find(d => d.name === doc);
                  return (
                    <div key={doc} className="border rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-5 w-5 text-gray-400" />
                          <span className="text-sm font-medium text-gray-700">{doc}</span>
                        </div>
                        {!uploadedDoc ? (
                          <button
                            onClick={() => handleDocumentUpload(doc)}
                            className="btn-secondary text-sm"
                          >
                            <Upload className="h-4 w-4 mr-2" />
                            Upload
                          </button>
                        ) : (
                          <div className="flex items-center">
                            {uploadedDoc.status === 'completed' ? (
                              <Check className="h-5 w-5 text-green-500" />
                            ) : (
                              <div className="text-sm text-blue-600">
                                {uploadedDoc.progress}%
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      {uploadedDoc && uploadedDoc.status === 'uploading' && (
                        <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-600 transition-all duration-300"
                            style={{ width: `${uploadedDoc.progress}%` }}
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-gray-200 flex justify-between">
          {step > 1 && (
            <button 
              onClick={() => setStep(step - 1)}
              className="btn-secondary"
            >
              Previous
            </button>
          )}
          <button 
            onClick={() => {
              if (step < 2) setStep(step + 1);
              else {
                // Submit application
                console.log('Submitting application:', { formData, documents });
                onClose();
              }
            }}
            className="btn-primary ml-auto"
          >
            {step < 2 ? 'Next' : 'Submit Application'}
          </button>
        </div>
      </div>
    </div>
  );
}