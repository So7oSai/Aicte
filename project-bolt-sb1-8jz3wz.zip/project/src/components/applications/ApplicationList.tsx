import React, { useState } from 'react';
import { FileText, Search, Filter, Download, Eye, MoreVertical } from 'lucide-react';
import { Application } from '../../types';
import ApplicationForm from './ApplicationForm';
import ApplicationView from './ApplicationView';

const applications: Application[] = [
  {
    id: 'APL20240001',
    institutionId: 'INS001',
    institutionName: 'Technical Institute of Engineering',
    type: 'new',
    status: 'under_review',
    submissionDate: '2024-03-15',
    documents: [
      {
        id: 'DOC001',
        name: 'Institution Registration',
        type: 'pdf',
        status: 'verified',
        url: '#'
      },
      {
        id: 'DOC002',
        name: 'Land Documents',
        type: 'pdf',
        status: 'pending',
        url: '#'
      }
    ]
  },
  // ... (previous applications data)
];

const statusColors = {
  draft: 'bg-gray-100 text-gray-800',
  submitted: 'bg-yellow-100 text-yellow-800',
  under_review: 'bg-blue-100 text-blue-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800'
};

export default function ApplicationList() {
  const [showNewApplication, setShowNewApplication] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const filteredApplications = applications.filter(app => {
    const matchesSearch = app.institutionName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || app.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleExport = () => {
    const csvContent = [
      ['Application ID', 'Institution', 'Type', 'Status', 'Submission Date'],
      ...filteredApplications.map(app => [
        app.id,
        app.institutionName,
        app.type,
        app.status,
        app.submissionDate
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'applications.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Applications</h2>
          <button 
            onClick={() => setShowNewApplication(true)}
            className="btn-primary flex items-center space-x-2"
          >
            <FileText className="h-4 w-4" />
            <span>New Application</span>
          </button>
        </div>

        <div className="flex space-x-4 mb-6">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search applications..."
              className="input-field pl-10"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <div className="relative">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="btn-secondary flex items-center space-x-2"
            >
              <Filter className="h-4 w-4" />
              <span>Filters</span>
            </button>
            {showFilters && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 border border-gray-200 z-10">
                <div className="px-4 py-2 border-b border-gray-200">
                  <h3 className="font-medium text-gray-700">Status</h3>
                </div>
                {Object.keys(statusColors).map(status => (
                  <button
                    key={status}
                    onClick={() => {
                      setFilterStatus(status);
                      setShowFilters(false);
                    }}
                    className="w-full px-4 py-2 text-left hover:bg-gray-50 text-sm"
                  >
                    {status.replace('_', ' ').toUpperCase()}
                  </button>
                ))}
                <button
                  onClick={() => {
                    setFilterStatus('all');
                    setShowFilters(false);
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-gray-50 text-sm border-t border-gray-200"
                >
                  Show All
                </button>
              </div>
            )}
          </div>
          <button 
            onClick={handleExport}
            className="btn-secondary flex items-center space-x-2"
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Application ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Institution
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Submission Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredApplications.map((application) => (
                <tr key={application.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {application.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {application.institutionName}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">
                    {application.type}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[application.status]}`}>
                      {application.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(application.submissionDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button 
                      onClick={() => setSelectedApplication(application)}
                      className="text-blue-600 hover:text-blue-800 mr-3"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                    <button className="text-gray-400 hover:text-gray-600">
                      <MoreVertical className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showNewApplication && (
        <ApplicationForm onClose={() => setShowNewApplication(false)} />
      )}

      {selectedApplication && (
        <ApplicationView 
          application={selectedApplication}
          onClose={() => setSelectedApplication(null)}
        />
      )}
    </div>
  );
}