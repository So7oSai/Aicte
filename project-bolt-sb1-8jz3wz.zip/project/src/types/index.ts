export interface Institution {
  id: string;
  name: string;
  type: string;
  location: string;
  status: 'pending' | 'approved' | 'rejected' | 'under_review';
  lastUpdated: string;
}

export interface Application {
  id: string;
  institutionId: string;
  institutionName: string;
  type: 'new' | 'renewal' | 'extension';
  status: 'draft' | 'submitted' | 'under_review' | 'approved' | 'rejected';
  submissionDate: string;
  documents: Document[];
}

export interface Document {
  id: string;
  name: string;
  type: string;
  status: 'pending' | 'verified' | 'rejected';
  url: string;
}

export interface User {
  id: string;
  name: string;
  role: 'admin' | 'evaluator' | 'institution';
  email: string;
  avatar?: string;
}